{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4  \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Card\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/card"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Label\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/label"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 ScrollArea\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/scroll-area"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ cn \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/lib/utils"\cf0 \strokec4 ;\cb1 \
\
\cf2 \cb3 \strokec2 const\cf0 \strokec4  layouts = [\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \{ id: \cf6 \strokec6 'title-only'\cf0 \strokec4 , name: \cf6 \strokec6 'Title Only'\cf0 \strokec4 , preview: \cf6 \strokec6 'T'\cf0 \strokec4  \},\cb1 \
\cb3   \{ id: \cf6 \strokec6 'title-content'\cf0 \strokec4 , name: \cf6 \strokec6 'Title & Content'\cf0 \strokec4 , preview: \cf6 \strokec6 'T\\n\'95\'95\'95'\cf0 \strokec4  \},\cb1 \
\cb3   \{ id: \cf6 \strokec6 'two-columns'\cf0 \strokec4 , name: \cf6 \strokec6 'Two Columns'\cf0 \strokec4 , preview: \cf6 \strokec6 '\'95\'95 | \'95\'95'\cf0 \strokec4  \},\cb1 \
\cb3   \{ id: \cf6 \strokec6 'title-image'\cf0 \strokec4 , name: \cf6 \strokec6 'Title & Image'\cf0 \strokec4 , preview: \cf6 \strokec6 'T\\n[IMG]'\cf0 \strokec4  \},\cb1 \
\cb3   \{ id: \cf6 \strokec6 'comparison'\cf0 \strokec4 , name: \cf6 \strokec6 'Comparison'\cf0 \strokec4 , preview: \cf6 \strokec6 'A vs B'\cf0 \strokec4  \},\cb1 \
\cb3   \{ id: \cf6 \strokec6 'section-header'\cf0 \strokec4 , name: \cf6 \strokec6 'Section Header'\cf0 \strokec4 , preview: \cf6 \strokec6 'SECTION'\cf0 \strokec4  \},\cb1 \
\cb3   \{ id: \cf6 \strokec6 'quote'\cf0 \strokec4 , name: \cf6 \strokec6 'Quote'\cf0 \strokec4 , preview: \cf6 \strokec6 '"\'85"'\cf0 \strokec4  \},\cb1 \
\cb3   \{ id: \cf6 \strokec6 'image-full'\cf0 \strokec4 , name: \cf6 \strokec6 'Full Image'\cf0 \strokec4 , preview: \cf6 \strokec6 '[IMG]'\cf0 \strokec4  \},\cb1 \
\cb3 ];\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 LayoutPanel\cf0 \strokec4 (\{ currentLayout, onLayoutChange \}) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <\cf5 \strokec5 Card\cf0 \strokec4  className=\cf6 \strokec6 "p-4"\cf0 \strokec4 >\cb1 \
\cb3       <\cf5 \strokec5 Label\cf0 \strokec4  className=\cf6 \strokec6 "text-sm font-semibold mb-3 block"\cf0 \strokec4 >\cf5 \strokec5 Slide\cf0 \strokec4  \cf5 \strokec5 Layout\cf0 \strokec4 </\cf5 \strokec5 Label\cf0 \strokec4 >\cb1 \
\cb3       <\cf5 \strokec5 ScrollArea\cf0 \strokec4  className=\cf6 \strokec6 "h-64"\cf0 \strokec4 >\cb1 \
\cb3         <div className=\cf6 \strokec6 "grid grid-cols-2 gap-2"\cf0 \strokec4 >\cb1 \
\cb3           \{layouts.map((layout) => (\cb1 \
\cb3             <button\cb1 \
\cb3               key=\{layout.id\}\cb1 \
\cb3               onClick=\{() => onLayoutChange(layout.id)\}\cb1 \
\cb3               className=\{cn(\cb1 \
\cb3                 \cf6 \strokec6 "aspect-[16/9] border-2 rounded-lg p-2 text-xs font-mono transition-all hover:border-indigo-400"\cf0 \strokec4 ,\cb1 \
\cb3                 currentLayout === layout.id\cb1 \
\cb3                   ? \cf6 \strokec6 "border-indigo-600 bg-indigo-50"\cf0 \cb1 \strokec4 \
\cb3                   : \cf6 \strokec6 "border-slate-200 bg-white"\cf0 \cb1 \strokec4 \
\cb3               )\}\cb1 \
\cb3             >\cb1 \
\cb3               <div className=\cf6 \strokec6 "h-full flex items-center justify-center whitespace-pre-line text-slate-600"\cf0 \strokec4 >\cb1 \
\cb3                 \{layout.preview\}\cb1 \
\cb3               </div>\cb1 \
\cb3               <p className=\cf6 \strokec6 "text-[10px] mt-1 text-slate-600"\cf0 \strokec4 >\{layout.name\}</p>\cb1 \
\cb3             </button>\cb1 \
\cb3           ))\}\cb1 \
\cb3         </div>\cb1 \
\cb3       </\cf5 \strokec5 ScrollArea\cf0 \strokec4 >\cb1 \
\cb3     </\cf5 \strokec5 Card\cf0 \strokec4 >\cb1 \
\cb3   );\cb1 \
\cb3 \}\cb1 \
}