{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;\red19\green118\blue70;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;\cssrgb\c3529\c52549\c34510;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4  \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Button\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/button"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf5 \strokec5 Bold\cf0 \strokec4 , \cf5 \strokec5 Italic\cf0 \strokec4 , \cf5 \strokec5 Underline\cf0 \strokec4 , \cf5 \strokec5 List\cf0 \strokec4 , \cf5 \strokec5 ListOrdered\cf0 \strokec4 , \cb1 \
\cb3   \cf5 \strokec5 AlignLeft\cf0 \strokec4 , \cf5 \strokec5 AlignCenter\cf0 \strokec4 , \cf5 \strokec5 AlignRight\cf0 \strokec4 , \cf5 \strokec5 Link\cf0 \strokec4  as \cf5 \strokec5 LinkIcon\cf0 \cb1 \strokec4 \
\cb3 \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'lucide-react'\cf0 \strokec4 ;\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 RichTextToolbar\cf0 \strokec4 (\{ position, onFormat \}) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf2 \strokec2 if\cf0 \strokec4  (!position) \cf2 \strokec2 return\cf0 \strokec4  \cf2 \strokec2 null\cf0 \strokec4 ;\cb1 \
\
\cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <div \cb1 \
\cb3       className=\cf6 \strokec6 "absolute bg-slate-900 rounded-lg shadow-2xl p-1 flex items-center gap-1 z-50"\cf0 \cb1 \strokec4 \
\cb3       style=\{\{ \cb1 \
\cb3         top: position.y - \cf7 \strokec7 50\cf0 \strokec4 , \cb1 \
\cb3         left: position.x,\cb1 \
\cb3         transform: \cf6 \strokec6 'translateX(-50%)'\cf0 \cb1 \strokec4 \
\cb3       \}\}\cb1 \
\cb3     >\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3         variant=\cf6 \strokec6 "ghost"\cf0 \cb1 \strokec4 \
\cb3         size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3         className=\cf6 \strokec6 "h-8 w-8 p-0 text-white hover:bg-slate-700"\cf0 \cb1 \strokec4 \
\cb3         onClick=\{() => onFormat(\cf6 \strokec6 'bold'\cf0 \strokec4 )\}\cb1 \
\cb3       >\cb1 \
\cb3         <\cf5 \strokec5 Bold\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3         variant=\cf6 \strokec6 "ghost"\cf0 \cb1 \strokec4 \
\cb3         size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3         className=\cf6 \strokec6 "h-8 w-8 p-0 text-white hover:bg-slate-700"\cf0 \cb1 \strokec4 \
\cb3         onClick=\{() => onFormat(\cf6 \strokec6 'italic'\cf0 \strokec4 )\}\cb1 \
\cb3       >\cb1 \
\cb3         <\cf5 \strokec5 Italic\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3         variant=\cf6 \strokec6 "ghost"\cf0 \cb1 \strokec4 \
\cb3         size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3         className=\cf6 \strokec6 "h-8 w-8 p-0 text-white hover:bg-slate-700"\cf0 \cb1 \strokec4 \
\cb3         onClick=\{() => onFormat(\cf6 \strokec6 'underline'\cf0 \strokec4 )\}\cb1 \
\cb3       >\cb1 \
\cb3         <\cf5 \strokec5 Underline\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       <div className=\cf6 \strokec6 "w-px h-6 bg-slate-700"\cf0 \strokec4  />\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3         variant=\cf6 \strokec6 "ghost"\cf0 \cb1 \strokec4 \
\cb3         size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3         className=\cf6 \strokec6 "h-8 w-8 p-0 text-white hover:bg-slate-700"\cf0 \cb1 \strokec4 \
\cb3         onClick=\{() => onFormat(\cf6 \strokec6 'bullet'\cf0 \strokec4 )\}\cb1 \
\cb3       >\cb1 \
\cb3         <\cf5 \strokec5 List\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3         variant=\cf6 \strokec6 "ghost"\cf0 \cb1 \strokec4 \
\cb3         size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3         className=\cf6 \strokec6 "h-8 w-8 p-0 text-white hover:bg-slate-700"\cf0 \cb1 \strokec4 \
\cb3         onClick=\{() => onFormat(\cf6 \strokec6 'numbered'\cf0 \strokec4 )\}\cb1 \
\cb3       >\cb1 \
\cb3         <\cf5 \strokec5 ListOrdered\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       <div className=\cf6 \strokec6 "w-px h-6 bg-slate-700"\cf0 \strokec4  />\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3         variant=\cf6 \strokec6 "ghost"\cf0 \cb1 \strokec4 \
\cb3         size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3         className=\cf6 \strokec6 "h-8 w-8 p-0 text-white hover:bg-slate-700"\cf0 \cb1 \strokec4 \
\cb3         onClick=\{() => onFormat(\cf6 \strokec6 'align-left'\cf0 \strokec4 )\}\cb1 \
\cb3       >\cb1 \
\cb3         <\cf5 \strokec5 AlignLeft\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3         variant=\cf6 \strokec6 "ghost"\cf0 \cb1 \strokec4 \
\cb3         size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3         className=\cf6 \strokec6 "h-8 w-8 p-0 text-white hover:bg-slate-700"\cf0 \cb1 \strokec4 \
\cb3         onClick=\{() => onFormat(\cf6 \strokec6 'align-center'\cf0 \strokec4 )\}\cb1 \
\cb3       >\cb1 \
\cb3         <\cf5 \strokec5 AlignCenter\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3         variant=\cf6 \strokec6 "ghost"\cf0 \cb1 \strokec4 \
\cb3         size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3         className=\cf6 \strokec6 "h-8 w-8 p-0 text-white hover:bg-slate-700"\cf0 \cb1 \strokec4 \
\cb3         onClick=\{() => onFormat(\cf6 \strokec6 'align-right'\cf0 \strokec4 )\}\cb1 \
\cb3       >\cb1 \
\cb3         <\cf5 \strokec5 AlignRight\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3     </div>\cb1 \
\cb3   );\cb1 \
\cb3 \}\cb1 \
}