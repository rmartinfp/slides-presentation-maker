{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4  \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Card\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/card"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Label\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/label"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Button\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/button"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ cn \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/lib/utils"\cf0 \strokec4 ;\cb1 \
\
\cf2 \cb3 \strokec2 const\cf0 \strokec4  fonts = [\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \{ name: \cf6 \strokec6 'Inter'\cf0 \strokec4 , family: \cf6 \strokec6 'Inter, sans-serif'\cf0 \strokec4  \},\cb1 \
\cb3   \{ name: \cf6 \strokec6 'Poppins'\cf0 \strokec4 , family: \cf6 \strokec6 'Poppins, sans-serif'\cf0 \strokec4  \},\cb1 \
\cb3   \{ name: \cf6 \strokec6 'Montserrat'\cf0 \strokec4 , family: \cf6 \strokec6 'Montserrat, sans-serif'\cf0 \strokec4  \},\cb1 \
\cb3   \{ name: \cf6 \strokec6 'Roboto'\cf0 \strokec4 , family: \cf6 \strokec6 'Roboto, sans-serif'\cf0 \strokec4  \},\cb1 \
\cb3   \{ name: \cf6 \strokec6 'Playfair Display'\cf0 \strokec4 , family: \cf6 \strokec6 'Playfair Display, serif'\cf0 \strokec4  \},\cb1 \
\cb3   \{ name: \cf6 \strokec6 'Lato'\cf0 \strokec4 , family: \cf6 \strokec6 'Lato, sans-serif'\cf0 \strokec4  \},\cb1 \
\cb3 ];\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 const\cf0 \strokec4  fontSizes = [\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \{ label: \cf6 \strokec6 'Small'\cf0 \strokec4 , value: \cf6 \strokec6 'text-sm'\cf0 \strokec4  \},\cb1 \
\cb3   \{ label: \cf6 \strokec6 'Medium'\cf0 \strokec4 , value: \cf6 \strokec6 'text-base'\cf0 \strokec4  \},\cb1 \
\cb3   \{ label: \cf6 \strokec6 'Large'\cf0 \strokec4 , value: \cf6 \strokec6 'text-lg'\cf0 \strokec4  \},\cb1 \
\cb3   \{ label: \cf6 \strokec6 'XL'\cf0 \strokec4 , value: \cf6 \strokec6 'text-xl'\cf0 \strokec4  \},\cb1 \
\cb3 ];\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 TypographyPanel\cf0 \strokec4 (\{ currentFont, currentSize, onFontChange, onSizeChange \}) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <\cf5 \strokec5 Card\cf0 \strokec4  className=\cf6 \strokec6 "p-4 space-y-4"\cf0 \strokec4 >\cb1 \
\cb3       <div>\cb1 \
\cb3         <\cf5 \strokec5 Label\cf0 \strokec4  className=\cf6 \strokec6 "text-sm font-semibold mb-3 block"\cf0 \strokec4 >\cf5 \strokec5 Font\cf0 \strokec4  \cf5 \strokec5 Family\cf0 \strokec4 </\cf5 \strokec5 Label\cf0 \strokec4 >\cb1 \
\cb3         <div className=\cf6 \strokec6 "space-y-2"\cf0 \strokec4 >\cb1 \
\cb3           \{fonts.map((font) => (\cb1 \
\cb3             <button\cb1 \
\cb3               key=\{font.name\}\cb1 \
\cb3               onClick=\{() => onFontChange(font.family)\}\cb1 \
\cb3               className=\{cn(\cb1 \
\cb3                 \cf6 \strokec6 "w-full text-left px-3 py-2 rounded-lg border transition-all"\cf0 \strokec4 ,\cb1 \
\cb3                 currentFont === font.family\cb1 \
\cb3                   ? \cf6 \strokec6 "border-indigo-600 bg-indigo-50"\cf0 \cb1 \strokec4 \
\cb3                   : \cf6 \strokec6 "border-slate-200 hover:border-slate-300"\cf0 \cb1 \strokec4 \
\cb3               )\}\cb1 \
\cb3               style=\{\{ fontFamily: font.family \}\}\cb1 \
\cb3             >\cb1 \
\cb3               \{font.name\}\cb1 \
\cb3             </button>\cb1 \
\cb3           ))\}\cb1 \
\cb3         </div>\cb1 \
\cb3       </div>\cb1 \
\
\cb3       <div>\cb1 \
\cb3         <\cf5 \strokec5 Label\cf0 \strokec4  className=\cf6 \strokec6 "text-sm font-semibold mb-3 block"\cf0 \strokec4 >\cf5 \strokec5 Size\cf0 \strokec4 </\cf5 \strokec5 Label\cf0 \strokec4 >\cb1 \
\cb3         <div className=\cf6 \strokec6 "flex gap-2"\cf0 \strokec4 >\cb1 \
\cb3           \{fontSizes.map((size) => (\cb1 \
\cb3             <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3               key=\{size.value\}\cb1 \
\cb3               variant=\{currentSize === size.value ? \cf6 \strokec6 'default'\cf0 \strokec4  : \cf6 \strokec6 'outline'\cf0 \strokec4 \}\cb1 \
\cb3               size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3               onClick=\{() => onSizeChange(size.value)\}\cb1 \
\cb3               className=\{currentSize === size.value ? \cf6 \strokec6 'bg-indigo-600'\cf0 \strokec4  : \cf6 \strokec6 ''\cf0 \strokec4 \}\cb1 \
\cb3             >\cb1 \
\cb3               \{size.label\}\cb1 \
\cb3             </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3           ))\}\cb1 \
\cb3         </div>\cb1 \
\cb3       </div>\cb1 \
\cb3     </\cf5 \strokec5 Card\cf0 \strokec4 >\cb1 \
\cb3   );\cb1 \
\cb3 \}\cb1 \
}