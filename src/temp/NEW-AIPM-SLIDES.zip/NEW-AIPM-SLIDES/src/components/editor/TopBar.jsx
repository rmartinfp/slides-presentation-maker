{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;\red19\green118\blue70;\red15\green112\blue1;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;\cssrgb\c3529\c52549\c34510;\cssrgb\c0\c50196\c0;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4 , \{ useState \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Button\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/button"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Input\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/input"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf5 \strokec5 ArrowLeft\cf0 \strokec4 , \cf5 \strokec5 Download\cf0 \strokec4 , \cf5 \strokec5 Share2\cf0 \strokec4 , \cf5 \strokec5 Play\cf0 \strokec4 , \cf5 \strokec5 Users\cf0 \strokec4 , \cf5 \strokec5 Sparkles\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 FileText\cf0 \strokec4 , \cf5 \strokec5 FileSpreadsheet\cf0 \strokec4 , \cf5 \strokec5 FileDown\cf0 \strokec4 , \cf5 \strokec5 Undo2\cf0 \strokec4 , \cf5 \strokec5 Redo2\cf0 \strokec4 , \cb1 \
\cb3   \cf5 \strokec5 ChevronDown\cf0 \strokec4 , \cf5 \strokec5 Eye\cf0 \cb1 \strokec4 \
\cb3 \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'lucide-react'\cf0 \strokec4 ;\cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Link\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react-router-dom'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ createPageUrl \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 '@/utils'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf5 \strokec5 DropdownMenu\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 DropdownMenuContent\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 DropdownMenuSeparator\cf0 \strokec4 ,\cb1 \
\cb3 \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/dropdown-menu"\cf0 \strokec4 ;\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 TopBar\cf0 \strokec4 (\{ \cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   title, \cb1 \
\cb3   onTitleChange, \cb1 \
\cb3   onPresentationMode,\cb1 \
\cb3   onShare,\cb1 \
\cb3   onExport,\cb1 \
\cb3   isPresentationMode,\cb1 \
\cb3   slideCount = \cf7 \strokec7 0\cf0 \strokec4 ,\cb1 \
\cb3   currentSlide = \cf7 \strokec7 0\cf0 \cb1 \strokec4 \
\cb3 \}) \{\cb1 \
\cb3   \cf2 \strokec2 const\cf0 \strokec4  [isEditingTitle, setIsEditingTitle] = useState(\cf2 \strokec2 false\cf0 \strokec4 );\cb1 \
\
\cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <div className=\cf6 \strokec6 "bg-white border-b border-slate-200 px-4 py-2 flex items-center gap-3"\cf0 \strokec4 >\cb1 \
\cb3       \{\cf8 \strokec8 /* Left section */\cf0 \strokec4 \}\cb1 \
\cb3       <div className=\cf6 \strokec6 "flex items-center gap-2"\cf0 \strokec4 >\cb1 \
\cb3         \{!isPresentationMode && (\cb1 \
\cb3           <\cf5 \strokec5 Link\cf0 \strokec4  to=\{createPageUrl(\cf6 \strokec6 'Entry'\cf0 \strokec4 )\}>\cb1 \
\cb3             <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "ghost"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "h-9 w-9 p-0"\cf0 \strokec4 >\cb1 \
\cb3               <\cf5 \strokec5 ArrowLeft\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3             </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3           </\cf5 \strokec5 Link\cf0 \strokec4 >\cb1 \
\cb3         )\}\cb1 \
\
\cb3         \{\cf8 \strokec8 /* Logo / Brand */\cf0 \strokec4 \}\cb1 \
\cb3         <div className=\cf6 \strokec6 "flex items-center gap-2 pr-4 border-r border-slate-200"\cf0 \strokec4 >\cb1 \
\cb3           <div className=\cf6 \strokec6 "w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center"\cf0 \strokec4 >\cb1 \
\cb3             <\cf5 \strokec5 Sparkles\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 text-white"\cf0 \strokec4  />\cb1 \
\cb3           </div>\cb1 \
\cb3         </div>\cb1 \
\cb3       </div>\cb1 \
\
\cb3       \{\cf8 \strokec8 /* Title */\cf0 \strokec4 \}\cb1 \
\cb3       <div className=\cf6 \strokec6 "flex-1 flex items-center gap-4"\cf0 \strokec4 >\cb1 \
\cb3         \{isPresentationMode ? (\cb1 \
\cb3           <h1 className=\cf6 \strokec6 "text-lg font-semibold text-slate-800"\cf0 \strokec4 >\{title\}</h1>\cb1 \
\cb3         ) : (\cb1 \
\cb3           <div className=\cf6 \strokec6 "flex items-center gap-2"\cf0 \strokec4 >\cb1 \
\cb3             \{isEditingTitle ? (\cb1 \
\cb3               <\cf5 \strokec5 Input\cf0 \cb1 \strokec4 \
\cb3                 value=\{title\}\cb1 \
\cb3                 onChange=\{(e) => onTitleChange(e.target.value)\}\cb1 \
\cb3                 onBlur=\{() => setIsEditingTitle(\cf2 \strokec2 false\cf0 \strokec4 )\}\cb1 \
\cb3                 onKeyDown=\{(e) => e.key === \cf6 \strokec6 'Enter'\cf0 \strokec4  && setIsEditingTitle(\cf2 \strokec2 false\cf0 \strokec4 )\}\cb1 \
\cb3                 className=\cf6 \strokec6 "text-base font-semibold border-0 focus-visible:ring-2 focus-visible:ring-indigo-500 px-2 h-9 max-w-xs bg-slate-50"\cf0 \cb1 \strokec4 \
\cb3                 placeholder=\cf6 \strokec6 "Untitled Presentation"\cf0 \cb1 \strokec4 \
\cb3                 autoFocus\cb1 \
\cb3               />\cb1 \
\cb3             ) : (\cb1 \
\cb3               <button\cb1 \
\cb3                 onClick=\{() => setIsEditingTitle(\cf2 \strokec2 true\cf0 \strokec4 )\}\cb1 \
\cb3                 className=\cf6 \strokec6 "text-base font-semibold text-slate-800 hover:bg-slate-100 px-2 py-1 rounded transition-colors max-w-xs truncate"\cf0 \cb1 \strokec4 \
\cb3               >\cb1 \
\cb3                 \{title || \cf6 \strokec6 'Untitled Presentation'\cf0 \strokec4 \}\cb1 \
\cb3               </button>\cb1 \
\cb3             )\}\cb1 \
\cb3             <span className=\cf6 \strokec6 "text-xs text-slate-400 bg-slate-100 px-2 py-1 rounded-full"\cf0 \strokec4 >\cb1 \
\cb3               \{slideCount\} slides\cb1 \
\cb3             </span>\cb1 \
\cb3           </div>\cb1 \
\cb3         )\}\cb1 \
\cb3       </div>\cb1 \
\
\cb3       \{\cf8 \strokec8 /* Center controls - only in edit mode */\cf0 \strokec4 \}\cb1 \
\cb3       \{!isPresentationMode && (\cb1 \
\cb3         <div className=\cf6 \strokec6 "hidden md:flex items-center gap-1 bg-slate-100 rounded-lg p-1"\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "ghost"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "h-8 w-8 p-0"\cf0 \strokec4  title=\cf6 \strokec6 "Undo"\cf0 \strokec4 >\cb1 \
\cb3             <\cf5 \strokec5 Undo2\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 text-slate-500"\cf0 \strokec4  />\cb1 \
\cb3           </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "ghost"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "h-8 w-8 p-0"\cf0 \strokec4  title=\cf6 \strokec6 "Redo"\cf0 \strokec4 >\cb1 \
\cb3             <\cf5 \strokec5 Redo2\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 text-slate-500"\cf0 \strokec4  />\cb1 \
\cb3           </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3         </div>\cb1 \
\cb3       )\}\cb1 \
\
\cb3       \{\cf8 \strokec8 /* Right section */\cf0 \strokec4 \}\cb1 \
\cb3       <div className=\cf6 \strokec6 "flex items-center gap-2"\cf0 \strokec4 >\cb1 \
\cb3         \{!isPresentationMode && (\cb1 \
\cb3           <>\cb1 \
\cb3             \{\cf8 \strokec8 /* Preview mode */\cf0 \strokec4 \}\cb1 \
\cb3             <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3               variant=\cf6 \strokec6 "ghost"\cf0 \cb1 \strokec4 \
\cb3               size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3               className=\cf6 \strokec6 "gap-2 h-9"\cf0 \cb1 \strokec4 \
\cb3               onClick=\{onPresentationMode\}\cb1 \
\cb3             >\cb1 \
\cb3               <\cf5 \strokec5 Eye\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3               <span className=\cf6 \strokec6 "hidden md:inline"\cf0 \strokec4 >\cf5 \strokec5 Preview\cf0 \strokec4 </span>\cb1 \
\cb3             </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\
\cb3             \{\cf8 \strokec8 /* Share */\cf0 \strokec4 \}\cb1 \
\cb3             <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3               variant=\cf6 \strokec6 "outline"\cf0 \cb1 \strokec4 \
\cb3               size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3               className=\cf6 \strokec6 "gap-2 h-9"\cf0 \cb1 \strokec4 \
\cb3               onClick=\{onShare\}\cb1 \
\cb3             >\cb1 \
\cb3               <\cf5 \strokec5 Users\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3               <span className=\cf6 \strokec6 "hidden md:inline"\cf0 \strokec4 >\cf5 \strokec5 Share\cf0 \strokec4 </span>\cb1 \
\cb3             </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\
\cb3             \{\cf8 \strokec8 /* Export dropdown */\cf0 \strokec4 \}\cb1 \
\cb3             <\cf5 \strokec5 DropdownMenu\cf0 \strokec4 >\cb1 \
\cb3               <\cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4  asChild>\cb1 \
\cb3                 <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "outline"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "gap-2 h-9"\cf0 \strokec4 >\cb1 \
\cb3                   <\cf5 \strokec5 Download\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3                   <span className=\cf6 \strokec6 "hidden md:inline"\cf0 \strokec4 >\cf5 \strokec5 Export\cf0 \strokec4 </span>\cb1 \
\cb3                   <\cf5 \strokec5 ChevronDown\cf0 \strokec4  className=\cf6 \strokec6 "w-3 h-3"\cf0 \strokec4  />\cb1 \
\cb3                 </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3               </\cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4 >\cb1 \
\cb3               <\cf5 \strokec5 DropdownMenuContent\cf0 \strokec4  align=\cf6 \strokec6 "end"\cf0 \strokec4  className=\cf6 \strokec6 "w-48"\cf0 \strokec4 >\cb1 \
\cb3                 <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onExport(\cf6 \strokec6 'pptx'\cf0 \strokec4 )\}>\cb1 \
\cb3                   <\cf5 \strokec5 FileText\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2"\cf0 \strokec4  />\cb1 \
\cb3                   \cf5 \strokec5 PowerPoint\cf0 \strokec4  (.pptx)\cb1 \
\cb3                 </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3                 <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onExport(\cf6 \strokec6 'google-slides'\cf0 \strokec4 )\}>\cb1 \
\cb3                   <\cf5 \strokec5 FileSpreadsheet\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2"\cf0 \strokec4  />\cb1 \
\cb3                   \cf5 \strokec5 Google\cf0 \strokec4  \cf5 \strokec5 Slides\cf0 \cb1 \strokec4 \
\cb3                 </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3                 <\cf5 \strokec5 DropdownMenuSeparator\cf0 \strokec4  />\cb1 \
\cb3                 <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onExport(\cf6 \strokec6 'pdf'\cf0 \strokec4 )\}>\cb1 \
\cb3                   <\cf5 \strokec5 FileDown\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2"\cf0 \strokec4  />\cb1 \
\cb3                   \cf5 \strokec5 PDF\cf0 \cb1 \strokec4 \
\cb3                 </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3               </\cf5 \strokec5 DropdownMenuContent\cf0 \strokec4 >\cb1 \
\cb3             </\cf5 \strokec5 DropdownMenu\cf0 \strokec4 >\cb1 \
\cb3           </>\cb1 \
\cb3         )\}\cb1 \
\
\cb3         \{\cf8 \strokec8 /* Present button */\cf0 \strokec4 \}\cb1 \
\cb3         <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3           size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3           className=\cf6 \strokec6 "bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 gap-2 h-9 shadow-md"\cf0 \cb1 \strokec4 \
\cb3           onClick=\{onPresentationMode\}\cb1 \
\cb3         >\cb1 \
\cb3           <\cf5 \strokec5 Play\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3           \{isPresentationMode ? \cf6 \strokec6 'Exit'\cf0 \strokec4  : \cf6 \strokec6 'Present'\cf0 \strokec4 \}\cb1 \
\cb3         </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       </div>\cb1 \
\cb3     </div>\cb1 \
\cb3   );\cb1 \
\cb3 \}\cb1 \
}