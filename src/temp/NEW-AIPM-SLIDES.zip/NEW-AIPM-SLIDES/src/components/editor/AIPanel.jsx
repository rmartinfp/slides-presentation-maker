{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4 , \{ useState \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Button\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/button"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Card\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/card"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Sparkles\cf0 \strokec4 , \cf5 \strokec5 Zap\cf0 \strokec4 , \cf5 \strokec5 Maximize2\cf0 \strokec4 , \cf5 \strokec5 Minimize2\cf0 \strokec4 , \cf5 \strokec5 RotateCw\cf0 \strokec4 , \cf5 \strokec5 Wand2\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'lucide-react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ base44 \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 '@/api/base44Client'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ toast \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'sonner'\cf0 \strokec4 ;\cb1 \
\
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 AIPanel\cf0 \strokec4 (\{ slide, onUpdateSlide \}) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf2 \strokec2 const\cf0 \strokec4  [isProcessing, setIsProcessing] = useState(\cf2 \strokec2 false\cf0 \strokec4 );\cb1 \
\
\cb3   \cf2 \strokec2 const\cf0 \strokec4  handleAIAction = \cf2 \strokec2 async\cf0 \strokec4  (action) => \{\cb1 \
\cb3     setIsProcessing(\cf2 \strokec2 true\cf0 \strokec4 );\cb1 \
\cb3     \cf2 \strokec2 try\cf0 \strokec4  \{\cb1 \
\cb3       \cf2 \strokec2 let\cf0 \strokec4  prompt = \cf6 \strokec6 ''\cf0 \strokec4 ;\cb1 \
\cb3       \cb1 \
\cb3       \cf2 \strokec2 switch\cf0 \strokec4 (action) \{\cb1 \
\cb3         \cf2 \strokec2 case\cf0 \strokec4  \cf6 \strokec6 'expand'\cf0 \strokec4 :\cb1 \
\cb3           prompt = \cf6 \strokec6 `Expand this slide content with more detail:\\nTitle: \cf0 \strokec4 $\{slide.title\}\cf6 \strokec6 \\nContent: \cf0 \strokec4 $\{slide.content?.join(\cf6 \strokec6 '\\n'\cf0 \strokec4 )\}\cf6 \strokec6 `\cf0 \strokec4 ;\cb1 \
\cb3           \cf2 \strokec2 break\cf0 \strokec4 ;\cb1 \
\cb3         \cf2 \strokec2 case\cf0 \strokec4  \cf6 \strokec6 'shorten'\cf0 \strokec4 :\cb1 \
\cb3           prompt = \cf6 \strokec6 `Make this slide content more concise:\\nTitle: \cf0 \strokec4 $\{slide.title\}\cf6 \strokec6 \\nContent: \cf0 \strokec4 $\{slide.content?.join(\cf6 \strokec6 '\\n'\cf0 \strokec4 )\}\cf6 \strokec6 `\cf0 \strokec4 ;\cb1 \
\cb3           \cf2 \strokec2 break\cf0 \strokec4 ;\cb1 \
\cb3         \cf2 \strokec2 case\cf0 \strokec4  \cf6 \strokec6 'regenerate'\cf0 \strokec4 :\cb1 \
\cb3           prompt = \cf6 \strokec6 `Regenerate this slide with fresh content:\\nTitle: \cf0 \strokec4 $\{slide.title\}\cf6 \strokec6 \\nContent: \cf0 \strokec4 $\{slide.content?.join(\cf6 \strokec6 '\\n'\cf0 \strokec4 )\}\cf6 \strokec6 `\cf0 \strokec4 ;\cb1 \
\cb3           \cf2 \strokec2 break\cf0 \strokec4 ;\cb1 \
\cb3         \cf2 \strokec2 case\cf0 \strokec4  \cf6 \strokec6 'enhance'\cf0 \strokec4 :\cb1 \
\cb3           prompt = \cf6 \strokec6 `Improve and enhance this slide:\\nTitle: \cf0 \strokec4 $\{slide.title\}\cf6 \strokec6 \\nContent: \cf0 \strokec4 $\{slide.content?.join(\cf6 \strokec6 '\\n'\cf0 \strokec4 )\}\cf6 \strokec6 `\cf0 \strokec4 ;\cb1 \
\cb3           \cf2 \strokec2 break\cf0 \strokec4 ;\cb1 \
\cb3       \}\cb1 \
\
\cb3       \cf2 \strokec2 const\cf0 \strokec4  response = \cf2 \strokec2 await\cf0 \strokec4  base44.integrations.\cf5 \strokec5 Core\cf0 \strokec4 .\cf5 \strokec5 InvokeLLM\cf0 \strokec4 (\{\cb1 \
\cb3         prompt: prompt + \cf6 \strokec6 '\\n\\nReturn a better version with title and bullet points.'\cf0 \strokec4 ,\cb1 \
\cb3         response_json_schema: \{\cb1 \
\cb3           type: \cf6 \strokec6 'object'\cf0 \strokec4 ,\cb1 \
\cb3           properties: \{\cb1 \
\cb3             title: \{ type: \cf6 \strokec6 'string'\cf0 \strokec4  \},\cb1 \
\cb3             content: \{\cb1 \
\cb3               type: \cf6 \strokec6 'array'\cf0 \strokec4 ,\cb1 \
\cb3               items: \{ type: \cf6 \strokec6 'string'\cf0 \strokec4  \}\cb1 \
\cb3             \}\cb1 \
\cb3           \}\cb1 \
\cb3         \}\cb1 \
\cb3       \});\cb1 \
\
\cb3       onUpdateSlide(\{\cb1 \
\cb3         ...slide,\cb1 \
\cb3         title: response.title,\cb1 \
\cb3         content: response.content\cb1 \
\cb3       \});\cb1 \
\
\cb3       toast.success(\cf6 \strokec6 'Slide updated with AI'\cf0 \strokec4 );\cb1 \
\cb3     \} \cf2 \strokec2 catch\cf0 \strokec4  (error) \{\cb1 \
\cb3       toast.error(\cf6 \strokec6 'Failed to process with AI'\cf0 \strokec4 );\cb1 \
\cb3     \} \cf2 \strokec2 finally\cf0 \strokec4  \{\cb1 \
\cb3       setIsProcessing(\cf2 \strokec2 false\cf0 \strokec4 );\cb1 \
\cb3     \}\cb1 \
\cb3   \};\cb1 \
\
\cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <\cf5 \strokec5 Card\cf0 \strokec4  className=\cf6 \strokec6 "p-4 bg-gradient-to-br from-purple-50 to-indigo-50 border-2 border-purple-200"\cf0 \strokec4 >\cb1 \
\cb3       <div className=\cf6 \strokec6 "flex items-center gap-2 mb-4"\cf0 \strokec4 >\cb1 \
\cb3         <div className=\cf6 \strokec6 "w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center shadow-lg"\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 Sparkles\cf0 \strokec4  className=\cf6 \strokec6 "w-5 h-5 text-white"\cf0 \strokec4  />\cb1 \
\cb3         </div>\cb1 \
\cb3         <div>\cb1 \
\cb3           <h3 className=\cf6 \strokec6 "font-semibold text-slate-900 text-sm"\cf0 \strokec4 >\cf5 \strokec5 AI\cf0 \strokec4  \cf5 \strokec5 Assistant\cf0 \strokec4 </h3>\cb1 \
\cb3           <p className=\cf6 \strokec6 "text-[10px] text-slate-600"\cf0 \strokec4 >\cf5 \strokec5 Enhance\cf0 \strokec4  instantly</p>\cb1 \
\cb3         </div>\cb1 \
\cb3       </div>\cb1 \
\
\cb3       <div className=\cf6 \strokec6 "space-y-2"\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3           size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3           className=\cf6 \strokec6 "w-full justify-start bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white"\cf0 \cb1 \strokec4 \
\cb3           onClick=\{() => handleAIAction(\cf6 \strokec6 'enhance'\cf0 \strokec4 )\}\cb1 \
\cb3           disabled=\{isProcessing\}\cb1 \
\cb3         >\cb1 \
\cb3           <\cf5 \strokec5 Wand2\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2"\cf0 \strokec4  />\cb1 \
\cb3           \cf5 \strokec5 Enhance\cf0 \strokec4  \cf2 \strokec2 with\cf0 \strokec4  \cf5 \strokec5 AI\cf0 \cb1 \strokec4 \
\cb3         </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\
\cb3         <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3           variant=\cf6 \strokec6 "outline"\cf0 \cb1 \strokec4 \
\cb3           size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3           className=\cf6 \strokec6 "w-full justify-start hover:bg-purple-50"\cf0 \cb1 \strokec4 \
\cb3           onClick=\{() => handleAIAction(\cf6 \strokec6 'expand'\cf0 \strokec4 )\}\cb1 \
\cb3           disabled=\{isProcessing\}\cb1 \
\cb3         >\cb1 \
\cb3           <\cf5 \strokec5 Maximize2\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2"\cf0 \strokec4  />\cb1 \
\cb3           \cf5 \strokec5 Expand\cf0 \strokec4  content\cb1 \
\cb3         </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\
\cb3         <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3           variant=\cf6 \strokec6 "outline"\cf0 \cb1 \strokec4 \
\cb3           size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3           className=\cf6 \strokec6 "w-full justify-start hover:bg-purple-50"\cf0 \cb1 \strokec4 \
\cb3           onClick=\{() => handleAIAction(\cf6 \strokec6 'shorten'\cf0 \strokec4 )\}\cb1 \
\cb3           disabled=\{isProcessing\}\cb1 \
\cb3         >\cb1 \
\cb3           <\cf5 \strokec5 Minimize2\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2"\cf0 \strokec4  />\cb1 \
\cb3           \cf5 \strokec5 Shorten\cf0 \strokec4  content\cb1 \
\cb3         </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\
\cb3         <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3           variant=\cf6 \strokec6 "outline"\cf0 \cb1 \strokec4 \
\cb3           size=\cf6 \strokec6 "sm"\cf0 \cb1 \strokec4 \
\cb3           className=\cf6 \strokec6 "w-full justify-start hover:bg-purple-50"\cf0 \cb1 \strokec4 \
\cb3           onClick=\{() => handleAIAction(\cf6 \strokec6 'regenerate'\cf0 \strokec4 )\}\cb1 \
\cb3           disabled=\{isProcessing\}\cb1 \
\cb3         >\cb1 \
\cb3           <\cf5 \strokec5 RotateCw\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2"\cf0 \strokec4  />\cb1 \
\cb3           \cf5 \strokec5 Regenerate\cf0 \cb1 \strokec4 \
\cb3         </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       </div>\cb1 \
\cb3     </\cf5 \strokec5 Card\cf0 \strokec4 >\cb1 \
\cb3   );\cb1 \
\cb3 \}}