{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;\red15\green112\blue1;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;\cssrgb\c0\c50196\c0;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4  \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Button\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/button"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf5 \strokec5 Type\cf0 \strokec4 , \cf5 \strokec5 Image\cf0 \strokec4 , \cf5 \strokec5 BarChart3\cf0 \strokec4 , \cf5 \strokec5 Layout\cf0 \strokec4 , \cf5 \strokec5 Palette\cf0 \strokec4 , \cb1 \
\cb3   \cf5 \strokec5 Sparkles\cf0 \strokec4 , \cf5 \strokec5 Plus\cf0 \strokec4 , \cf5 \strokec5 Download\cf0 \strokec4 , \cf5 \strokec5 Share2\cf0 \strokec4 , \cf5 \strokec5 Play\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 FileText\cf0 \cb1 \strokec4 \
\cb3 \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'lucide-react'\cf0 \strokec4 ;\cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf5 \strokec5 DropdownMenu\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 DropdownMenuContent\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4 ,\cb1 \
\cb3 \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/dropdown-menu"\cf0 \strokec4 ;\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 Toolbar\cf0 \strokec4 (\{ onAction, isPresentationMode \}) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf2 \strokec2 if\cf0 \strokec4  (isPresentationMode) \cf2 \strokec2 return\cf0 \strokec4  \cf2 \strokec2 null\cf0 \strokec4 ;\cb1 \
\
\cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <div className=\cf6 \strokec6 "bg-white border-b border-slate-200 px-4 py-2 flex items-center gap-2 overflow-x-auto"\cf0 \strokec4 >\cb1 \
\cb3       \{\cf7 \strokec7 /* Text */\cf0 \strokec4 \}\cb1 \
\cb3       <\cf5 \strokec5 DropdownMenu\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4  asChild>\cb1 \
\cb3           <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "ghost"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "gap-2"\cf0 \strokec4 >\cb1 \
\cb3             <\cf5 \strokec5 Type\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3             \cf5 \strokec5 Text\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3         </\cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 DropdownMenuContent\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'add-text'\cf0 \strokec4 )\}>\cb1 \
\cb3             \cf5 \strokec5 Add\cf0 \strokec4  \cf5 \strokec5 Text\cf0 \strokec4  \cf5 \strokec5 Box\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'add-heading'\cf0 \strokec4 )\}>\cb1 \
\cb3             \cf5 \strokec5 Add\cf0 \strokec4  \cf5 \strokec5 Heading\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'add-subtitle'\cf0 \strokec4 )\}>\cb1 \
\cb3             \cf5 \strokec5 Add\cf0 \strokec4  \cf5 \strokec5 Subtitle\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3         </\cf5 \strokec5 DropdownMenuContent\cf0 \strokec4 >\cb1 \
\cb3       </\cf5 \strokec5 DropdownMenu\cf0 \strokec4 >\cb1 \
\
\cb3       \{\cf7 \strokec7 /* Images */\cf0 \strokec4 \}\cb1 \
\cb3       <\cf5 \strokec5 DropdownMenu\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4  asChild>\cb1 \
\cb3           <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "ghost"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "gap-2"\cf0 \strokec4 >\cb1 \
\cb3             <\cf5 \strokec5 Image\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3             \cf5 \strokec5 Image\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3         </\cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 DropdownMenuContent\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'upload-image'\cf0 \strokec4 )\}>\cb1 \
\cb3             \cf5 \strokec5 Upload\cf0 \strokec4  \cf5 \strokec5 Image\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'generate-image'\cf0 \strokec4 )\}>\cb1 \
\cb3             <\cf5 \strokec5 Sparkles\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2"\cf0 \strokec4  />\cb1 \
\cb3             \cf5 \strokec5 Generate\cf0 \strokec4  \cf2 \strokec2 with\cf0 \strokec4  \cf5 \strokec5 AI\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3         </\cf5 \strokec5 DropdownMenuContent\cf0 \strokec4 >\cb1 \
\cb3       </\cf5 \strokec5 DropdownMenu\cf0 \strokec4 >\cb1 \
\
\cb3       \{\cf7 \strokec7 /* Charts */\cf0 \strokec4 \}\cb1 \
\cb3       <\cf5 \strokec5 DropdownMenu\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4  asChild>\cb1 \
\cb3           <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "ghost"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "gap-2"\cf0 \strokec4 >\cb1 \
\cb3             <\cf5 \strokec5 BarChart3\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3             \cf5 \strokec5 Chart\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3         </\cf5 \strokec5 DropdownMenuTrigger\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 DropdownMenuContent\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'add-bar-chart'\cf0 \strokec4 )\}>\cb1 \
\cb3             \cf5 \strokec5 Bar\cf0 \strokec4  \cf5 \strokec5 Chart\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'add-line-chart'\cf0 \strokec4 )\}>\cb1 \
\cb3             \cf5 \strokec5 Line\cf0 \strokec4  \cf5 \strokec5 Chart\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'add-pie-chart'\cf0 \strokec4 )\}>\cb1 \
\cb3             \cf5 \strokec5 Pie\cf0 \strokec4  \cf5 \strokec5 Chart\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 DropdownMenuItem\cf0 \strokec4 >\cb1 \
\cb3         </\cf5 \strokec5 DropdownMenuContent\cf0 \strokec4 >\cb1 \
\cb3       </\cf5 \strokec5 DropdownMenu\cf0 \strokec4 >\cb1 \
\
\cb3       \{\cf7 \strokec7 /* Layout */\cf0 \strokec4 \}\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "ghost"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "gap-2"\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'change-layout'\cf0 \strokec4 )\}>\cb1 \
\cb3         <\cf5 \strokec5 Layout\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3         \cf5 \strokec5 Layout\cf0 \cb1 \strokec4 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\
\cb3       \{\cf7 \strokec7 /* Typography */\cf0 \strokec4 \}\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "ghost"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "gap-2"\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'change-font'\cf0 \strokec4 )\}>\cb1 \
\cb3         <\cf5 \strokec5 Type\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3         \cf5 \strokec5 Font\cf0 \cb1 \strokec4 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\
\cb3       \{\cf7 \strokec7 /* Colors */\cf0 \strokec4 \}\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "ghost"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "gap-2"\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'change-colors'\cf0 \strokec4 )\}>\cb1 \
\cb3         <\cf5 \strokec5 Palette\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3         \cf5 \strokec5 Colors\cf0 \cb1 \strokec4 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\
\cb3       <div className=\cf6 \strokec6 "flex-1"\cf0 \strokec4  />\cb1 \
\
\cb3       \{\cf7 \strokec7 /* AI Tools */\cf0 \strokec4 \}\cb1 \
\cb3       <\cf5 \strokec5 Button\cf0 \strokec4  variant=\cf6 \strokec6 "outline"\cf0 \strokec4  size=\cf6 \strokec6 "sm"\cf0 \strokec4  className=\cf6 \strokec6 "gap-2"\cf0 \strokec4  onClick=\{() => onAction(\cf6 \strokec6 'ai-enhance'\cf0 \strokec4 )\}>\cb1 \
\cb3         <\cf5 \strokec5 Sparkles\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3         \cf5 \strokec5 AI\cf0 \strokec4  \cf5 \strokec5 Enhance\cf0 \cb1 \strokec4 \
\cb3       </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3     </div>\cb1 \
\cb3   );\cb1 \
\cb3 \}\cb1 \
}