{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;\red191\green28\blue37;\red19\green118\blue70;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;\cssrgb\c80392\c19216\c19216;\cssrgb\c3529\c52549\c34510;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4 , \{ useState \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Textarea\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/textarea"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 MessageSquare\cf0 \strokec4 , \cf5 \strokec5 ChevronUp\cf0 \strokec4 , \cf5 \strokec5 ChevronDown\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'lucide-react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ cn \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/lib/utils"\cf0 \strokec4 ;\cb1 \
\
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 SpeakerNotes\cf0 \strokec4 (\{ notes, onChange, isPresentationMode \}) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf2 \strokec2 const\cf0 \strokec4  [isExpanded, setIsExpanded] = useState(\cf2 \strokec2 false\cf0 \strokec4 );\cb1 \
\
\cb3   \cf2 \strokec2 if\cf0 \strokec4  (isPresentationMode) \{\cb1 \
\cb3     \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3       <div className=\cf6 \strokec6 "fixed bottom-0 left-0 right-0 bg-slate-900/95 text-white p-4 backdrop-blur"\cf0 \strokec4 >\cb1 \
\cb3         <p className=\cf6 \strokec6 "text-sm"\cf0 \strokec4 >\{notes || \cf6 \strokec6 'No speaker notes for this slide'\cf0 \strokec4 \}</p>\cb1 \
\cb3       </div>\cb1 \
\cb3     );\cb1 \
\cb3   \}\cb1 \
\
\cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <div className=\cf6 \strokec6 "bg-white rounded-xl shadow-md overflow-hidden"\cf0 \strokec4 >\cb1 \
\cb3       <button\cb1 \
\cb3         onClick=\{() => setIsExpanded(!isExpanded)\}\cb1 \
\cb3         className=\cf6 \strokec6 "w-full px-4 py-2 flex items-center justify-between hover:bg-slate-50 transition-colors"\cf0 \cb1 \strokec4 \
\cb3       >\cb1 \
\cb3         <div className=\cf6 \strokec6 "flex items-center gap-2"\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 MessageSquare\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 text-slate-400"\cf0 \strokec4  />\cb1 \
\cb3           <span className=\cf6 \strokec6 "text-sm font-medium text-slate-600"\cf0 \strokec4 >\cf5 \strokec5 Speaker\cf0 \strokec4  \cf5 \strokec5 Notes\cf0 \strokec4 </span>\cb1 \
\cb3           \{notes && !isExpanded && (\cb1 \
\cb3             <span className=\cf6 \strokec6 "text-xs text-slate-400 truncate max-w-xs"\cf0 \strokec4 >\cb1 \
\cb3               \cf7 \strokec7 \'97\cf0 \strokec4  \{notes.slice(\cf8 \strokec8 0\cf0 \strokec4 , \cf8 \strokec8 50\cf0 \strokec4 )\}...\cb1 \
\cb3             </span>\cb1 \
\cb3           )\}\cb1 \
\cb3         </div>\cb1 \
\cb3         \{isExpanded ? (\cb1 \
\cb3           <\cf5 \strokec5 ChevronDown\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 text-slate-400"\cf0 \strokec4  />\cb1 \
\cb3         ) : (\cb1 \
\cb3           <\cf5 \strokec5 ChevronUp\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 text-slate-400"\cf0 \strokec4  />\cb1 \
\cb3         )\}\cb1 \
\cb3       </button>\cb1 \
\cb3       \cb1 \
\cb3       <div className=\{cn(\cb1 \
\cb3         \cf6 \strokec6 "overflow-hidden transition-all duration-200"\cf0 \strokec4 ,\cb1 \
\cb3         isExpanded ? \cf6 \strokec6 "max-h-40"\cf0 \strokec4  : \cf6 \strokec6 "max-h-0"\cf0 \cb1 \strokec4 \
\cb3       )\}>\cb1 \
\cb3         <div className=\cf6 \strokec6 "px-4 pb-4"\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 Textarea\cf0 \cb1 \strokec4 \
\cb3             value=\{notes || \cf6 \strokec6 ''\cf0 \strokec4 \}\cb1 \
\cb3             onChange=\{(e) => onChange(e.target.value)\}\cb1 \
\cb3             placeholder=\cf6 \strokec6 "Add notes for yourself during the presentation..."\cf0 \cb1 \strokec4 \
\cb3             className=\cf6 \strokec6 "resize-none h-24 text-sm"\cf0 \cb1 \strokec4 \
\cb3           />\cb1 \
\cb3         </div>\cb1 \
\cb3       </div>\cb1 \
\cb3     </div>\cb1 \
\cb3   );\cb1 \
\cb3 \}\cb1 \
}