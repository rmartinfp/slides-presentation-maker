{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;\red19\green118\blue70;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;\cssrgb\c3529\c52549\c34510;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4 , \{ useState \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Card\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/card"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Label\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/label"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Button\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/button"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Input\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/input"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Textarea\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/textarea"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Upload\cf0 \strokec4 , \cf5 \strokec5 Sparkles\cf0 \strokec4 , \cf5 \strokec5 Link\cf0 \strokec4  as \cf5 \strokec5 LinkIcon\cf0 \strokec4 , \cf5 \strokec5 Loader2\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'lucide-react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ base44 \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 '@/api/base44Client'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ toast \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'sonner'\cf0 \strokec4 ;\cb1 \
\
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 ImagePanel\cf0 \strokec4 (\{ onAddImage \}) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf2 \strokec2 const\cf0 \strokec4  [aiPrompt, setAiPrompt] = useState(\cf6 \strokec6 ''\cf0 \strokec4 );\cb1 \
\cb3   \cf2 \strokec2 const\cf0 \strokec4  [isGenerating, setIsGenerating] = useState(\cf2 \strokec2 false\cf0 \strokec4 );\cb1 \
\cb3   \cf2 \strokec2 const\cf0 \strokec4  [imageUrl, setImageUrl] = useState(\cf6 \strokec6 ''\cf0 \strokec4 );\cb1 \
\
\cb3   \cf2 \strokec2 const\cf0 \strokec4  handleFileUpload = \cf2 \strokec2 async\cf0 \strokec4  (e) => \{\cb1 \
\cb3     \cf2 \strokec2 const\cf0 \strokec4  file = e.target.files[\cf7 \strokec7 0\cf0 \strokec4 ];\cb1 \
\cb3     \cf2 \strokec2 if\cf0 \strokec4  (!file) \cf2 \strokec2 return\cf0 \strokec4 ;\cb1 \
\
\cb3     \cf2 \strokec2 try\cf0 \strokec4  \{\cb1 \
\cb3       \cf2 \strokec2 const\cf0 \strokec4  result = \cf2 \strokec2 await\cf0 \strokec4  base44.integrations.\cf5 \strokec5 Core\cf0 \strokec4 .\cf5 \strokec5 UploadFile\cf0 \strokec4 (\{ file \});\cb1 \
\cb3       onAddImage(result.file_url);\cb1 \
\cb3       toast.success(\cf6 \strokec6 'Image uploaded!'\cf0 \strokec4 );\cb1 \
\cb3     \} \cf2 \strokec2 catch\cf0 \strokec4  (error) \{\cb1 \
\cb3       toast.error(\cf6 \strokec6 'Failed to upload image'\cf0 \strokec4 );\cb1 \
\cb3     \}\cb1 \
\cb3   \};\cb1 \
\
\cb3   \cf2 \strokec2 const\cf0 \strokec4  handleGenerateImage = \cf2 \strokec2 async\cf0 \strokec4  () => \{\cb1 \
\cb3     \cf2 \strokec2 if\cf0 \strokec4  (!aiPrompt.trim()) \cf2 \strokec2 return\cf0 \strokec4 ;\cb1 \
\
\cb3     setIsGenerating(\cf2 \strokec2 true\cf0 \strokec4 );\cb1 \
\cb3     \cf2 \strokec2 try\cf0 \strokec4  \{\cb1 \
\cb3       \cf2 \strokec2 const\cf0 \strokec4  result = \cf2 \strokec2 await\cf0 \strokec4  base44.integrations.\cf5 \strokec5 Core\cf0 \strokec4 .\cf5 \strokec5 GenerateImage\cf0 \strokec4 (\{\cb1 \
\cb3         prompt: aiPrompt\cb1 \
\cb3       \});\cb1 \
\cb3       onAddImage(result.url);\cb1 \
\cb3       toast.success(\cf6 \strokec6 'Image generated!'\cf0 \strokec4 );\cb1 \
\cb3       setAiPrompt(\cf6 \strokec6 ''\cf0 \strokec4 );\cb1 \
\cb3     \} \cf2 \strokec2 catch\cf0 \strokec4  (error) \{\cb1 \
\cb3       toast.error(\cf6 \strokec6 'Failed to generate image'\cf0 \strokec4 );\cb1 \
\cb3     \} \cf2 \strokec2 finally\cf0 \strokec4  \{\cb1 \
\cb3       setIsGenerating(\cf2 \strokec2 false\cf0 \strokec4 );\cb1 \
\cb3     \}\cb1 \
\cb3   \};\cb1 \
\
\cb3   \cf2 \strokec2 const\cf0 \strokec4  handleAddFromUrl = () => \{\cb1 \
\cb3     \cf2 \strokec2 if\cf0 \strokec4  (!imageUrl.trim()) \cf2 \strokec2 return\cf0 \strokec4 ;\cb1 \
\cb3     onAddImage(imageUrl);\cb1 \
\cb3     toast.success(\cf6 \strokec6 'Image added!'\cf0 \strokec4 );\cb1 \
\cb3     setImageUrl(\cf6 \strokec6 ''\cf0 \strokec4 );\cb1 \
\cb3   \};\cb1 \
\
\cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <\cf5 \strokec5 Card\cf0 \strokec4  className=\cf6 \strokec6 "p-4 space-y-4"\cf0 \strokec4 >\cb1 \
\cb3       <div>\cb1 \
\cb3         <\cf5 \strokec5 Label\cf0 \strokec4  className=\cf6 \strokec6 "text-sm font-semibold mb-3 block flex items-center gap-2"\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 Upload\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3           \cf5 \strokec5 Upload\cf0 \strokec4  \cf5 \strokec5 Image\cf0 \cb1 \strokec4 \
\cb3         </\cf5 \strokec5 Label\cf0 \strokec4 >\cb1 \
\cb3         <input\cb1 \
\cb3           type=\cf6 \strokec6 "file"\cf0 \cb1 \strokec4 \
\cb3           accept=\cf6 \strokec6 "image/*"\cf0 \cb1 \strokec4 \
\cb3           onChange=\{handleFileUpload\}\cb1 \
\cb3           className=\cf6 \strokec6 "text-sm"\cf0 \cb1 \strokec4 \
\cb3         />\cb1 \
\cb3       </div>\cb1 \
\
\cb3       <div className=\cf6 \strokec6 "border-t pt-4"\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 Label\cf0 \strokec4  className=\cf6 \strokec6 "text-sm font-semibold mb-3 block flex items-center gap-2"\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 Sparkles\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3           \cf5 \strokec5 Generate\cf0 \strokec4  \cf2 \strokec2 with\cf0 \strokec4  \cf5 \strokec5 AI\cf0 \cb1 \strokec4 \
\cb3         </\cf5 \strokec5 Label\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 Textarea\cf0 \cb1 \strokec4 \
\cb3           value=\{aiPrompt\}\cb1 \
\cb3           onChange=\{(e) => setAiPrompt(e.target.value)\}\cb1 \
\cb3           placeholder=\cf6 \strokec6 "Describe the image you want to generate..."\cf0 \cb1 \strokec4 \
\cb3           className=\cf6 \strokec6 "text-sm mb-2 h-20"\cf0 \cb1 \strokec4 \
\cb3         />\cb1 \
\cb3         <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3           onClick=\{handleGenerateImage\}\cb1 \
\cb3           disabled=\{isGenerating || !aiPrompt.trim()\}\cb1 \
\cb3           className=\cf6 \strokec6 "w-full bg-indigo-600"\cf0 \cb1 \strokec4 \
\cb3         >\cb1 \
\cb3           \{isGenerating ? (\cb1 \
\cb3             <>\cb1 \
\cb3               <\cf5 \strokec5 Loader2\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2 animate-spin"\cf0 \strokec4  />\cb1 \
\cb3               \cf5 \strokec5 Generating\cf0 \strokec4 ...\cb1 \
\cb3             </>\cb1 \
\cb3           ) : (\cb1 \
\cb3             <>\cb1 \
\cb3               <\cf5 \strokec5 Sparkles\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4 mr-2"\cf0 \strokec4  />\cb1 \
\cb3               \cf5 \strokec5 Generate\cf0 \cb1 \strokec4 \
\cb3             </>\cb1 \
\cb3           )\}\cb1 \
\cb3         </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3       </div>\cb1 \
\
\cb3       <div className=\cf6 \strokec6 "border-t pt-4"\cf0 \strokec4 >\cb1 \
\cb3         <\cf5 \strokec5 Label\cf0 \strokec4  className=\cf6 \strokec6 "text-sm font-semibold mb-3 block flex items-center gap-2"\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 LinkIcon\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3           \cf5 \strokec5 Add\cf0 \strokec4  \cf2 \strokec2 from\cf0 \strokec4  \cf5 \strokec5 URL\cf0 \cb1 \strokec4 \
\cb3         </\cf5 \strokec5 Label\cf0 \strokec4 >\cb1 \
\cb3         <div className=\cf6 \strokec6 "flex gap-2"\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 Input\cf0 \cb1 \strokec4 \
\cb3             value=\{imageUrl\}\cb1 \
\cb3             onChange=\{(e) => setImageUrl(e.target.value)\}\cb1 \
\cb3             placeholder=\cf6 \strokec6 "https://..."\cf0 \cb1 \strokec4 \
\cb3             className=\cf6 \strokec6 "text-sm"\cf0 \cb1 \strokec4 \
\cb3           />\cb1 \
\cb3           <\cf5 \strokec5 Button\cf0 \cb1 \strokec4 \
\cb3             onClick=\{handleAddFromUrl\}\cb1 \
\cb3             disabled=\{!imageUrl.trim()\}\cb1 \
\cb3             variant=\cf6 \strokec6 "outline"\cf0 \cb1 \strokec4 \
\cb3           >\cb1 \
\cb3             \cf5 \strokec5 Add\cf0 \cb1 \strokec4 \
\cb3           </\cf5 \strokec5 Button\cf0 \strokec4 >\cb1 \
\cb3         </div>\cb1 \
\cb3       </div>\cb1 \
\cb3     </\cf5 \strokec5 Card\cf0 \strokec4 >\cb1 \
\cb3   );\cb1 \
\cb3 \}\cb1 \
}