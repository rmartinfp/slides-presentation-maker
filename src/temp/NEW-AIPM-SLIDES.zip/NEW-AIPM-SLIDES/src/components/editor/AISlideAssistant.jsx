{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;\red15\green112\blue1;\red19\green118\blue70;\red191\green28\blue37;
}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;\cssrgb\c0\c50196\c0;\cssrgb\c3529\c52549\c34510;\cssrgb\c80392\c19216\c19216;
}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4 , \{ useState, useEffect \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ motion, \cf5 \strokec5 AnimatePresence\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'framer-motion'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf5 \strokec5 Sparkles\cf0 \strokec4 , \cf5 \strokec5 Lightbulb\cf0 \strokec4 , \cf5 \strokec5 Image\cf0 \strokec4 , \cf5 \strokec5 BarChart3\cf0 \strokec4 , \cb1 \
\cb3   \cf5 \strokec5 Quote\cf0 \strokec4 , \cf5 \strokec5 ListChecks\cf0 \strokec4 , \cf5 \strokec5 ArrowRight\cf0 \strokec4 , \cf5 \strokec5 X\cf0 \strokec4 , \cf5 \strokec5 Zap\cf0 \strokec4 ,\cb1 \
\cb3   \cf5 \strokec5 TrendingUp\cf0 \strokec4 , \cf5 \strokec5 Users\cf0 \strokec4 , \cf5 \strokec5 Target\cf0 \strokec4 , \cf5 \strokec5 Clock\cf0 \cb1 \strokec4 \
\cb3 \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'lucide-react'\cf0 \strokec4 ;\cb1 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Button\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/button"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ base44 \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 '@/api/base44Client'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ toast \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'sonner'\cf0 \strokec4 ;\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf7 \cb3 \strokec7 // AI-generated contextual suggestions based on slide content\cf0 \cb1 \strokec4 \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 AISlideAssistant\cf0 \strokec4 (\{ slide, onUpdateSlide, onAddImage, onAddChart \}) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf2 \strokec2 const\cf0 \strokec4  [suggestions, setSuggestions] = useState([]);\cb1 \
\cb3   \cf2 \strokec2 const\cf0 \strokec4  [isGenerating, setIsGenerating] = useState(\cf2 \strokec2 false\cf0 \strokec4 );\cb1 \
\cb3   \cf2 \strokec2 const\cf0 \strokec4  [isVisible, setIsVisible] = useState(\cf2 \strokec2 true\cf0 \strokec4 );\cb1 \
\cb3   \cf2 \strokec2 const\cf0 \strokec4  [appliedSuggestions, setAppliedSuggestions] = useState(\cf2 \strokec2 new\cf0 \strokec4  \cf5 \strokec5 Set\cf0 \strokec4 ());\cb1 \
\
\cb3   \cf7 \strokec7 // Generate suggestions based on slide content\cf0 \cb1 \strokec4 \
\cb3   useEffect(() => \{\cb1 \
\cb3     \cf2 \strokec2 if\cf0 \strokec4  (slide?.title || slide?.content?.length > \cf8 \strokec8 0\cf0 \strokec4 ) \{\cb1 \
\cb3       generateSuggestions();\cb1 \
\cb3     \}\cb1 \
\cb3   \}, [slide?.title]);\cb1 \
\
\cb3   \cf2 \strokec2 const\cf0 \strokec4  generateSuggestions = \cf2 \strokec2 async\cf0 \strokec4  () => \{\cb1 \
\cb3     setIsGenerating(\cf2 \strokec2 true\cf0 \strokec4 );\cb1 \
\cb3     \cb1 \
\cb3     \cf7 \strokec7 // Smart contextual suggestions based on content\cf0 \cb1 \strokec4 \
\cb3     \cf2 \strokec2 const\cf0 \strokec4  contentContext = \cf6 \strokec6 `\cf0 \strokec4 $\{slide?.title || \cf6 \strokec6 ''\cf0 \strokec4 \}\cf6 \strokec6  \cf0 \strokec4 $\{slide?.content?.join(\cf6 \strokec6 ' '\cf0 \strokec4 ) || \cf6 \strokec6 ''\cf0 \strokec4 \}\cf6 \strokec6 `\cf0 \strokec4 .toLowerCase();\cb1 \
\cb3     \cb1 \
\cb3     \cf2 \strokec2 const\cf0 \strokec4  baseSuggestions = [];\cb1 \
\
\cb3     \cf7 \strokec7 // Content-aware suggestions\cf0 \cb1 \strokec4 \
\cb3     \cf2 \strokec2 if\cf0 \strokec4  (contentContext.includes(\cf6 \strokec6 'problem'\cf0 \strokec4 ) || contentContext.includes(\cf6 \strokec6 'challenge'\cf0 \strokec4 )) \{\cb1 \
\cb3       baseSuggestions.push(\{\cb1 \
\cb3         id: \cf6 \strokec6 'add-solution'\cf0 \strokec4 ,\cb1 \
\cb3         icon: \cf5 \strokec5 Lightbulb\cf0 \strokec4 ,\cb1 \
\cb3         label: \cf6 \strokec6 'Add solution slide'\cf0 \strokec4 ,\cb1 \
\cb3         description: \cf6 \strokec6 'Create a follow-up slide with solutions'\cf0 \strokec4 ,\cb1 \
\cb3         type: \cf6 \strokec6 'slide'\cf0 \strokec4 ,\cb1 \
\cb3         color: \cf6 \strokec6 'text-amber-600 bg-amber-50'\cf0 \cb1 \strokec4 \
\cb3       \});\cb1 \
\cb3     \}\cb1 \
\
\cb3     \cf2 \strokec2 if\cf0 \strokec4  (contentContext.includes(\cf6 \strokec6 'data'\cf0 \strokec4 ) || contentContext.includes(\cf6 \strokec6 'result'\cf0 \strokec4 ) || contentContext.includes(\cf6 \strokec6 'growth'\cf0 \strokec4 )) \{\cb1 \
\cb3       baseSuggestions.push(\{\cb1 \
\cb3         id: \cf6 \strokec6 'add-chart'\cf0 \strokec4 ,\cb1 \
\cb3         icon: \cf5 \strokec5 BarChart3\cf0 \strokec4 ,\cb1 \
\cb3         label: \cf6 \strokec6 'Visualize with chart'\cf0 \strokec4 ,\cb1 \
\cb3         description: \cf6 \strokec6 'Add a chart to illustrate data'\cf0 \strokec4 ,\cb1 \
\cb3         type: \cf6 \strokec6 'chart'\cf0 \strokec4 ,\cb1 \
\cb3         color: \cf6 \strokec6 'text-blue-600 bg-blue-50'\cf0 \cb1 \strokec4 \
\cb3       \});\cb1 \
\cb3     \}\cb1 \
\
\cb3     \cf2 \strokec2 if\cf0 \strokec4  (contentContext.includes(\cf6 \strokec6 'team'\cf0 \strokec4 ) || contentContext.includes(\cf6 \strokec6 'people'\cf0 \strokec4 ) || contentContext.includes(\cf6 \strokec6 'customer'\cf0 \strokec4 )) \{\cb1 \
\cb3       baseSuggestions.push(\{\cb1 \
\cb3         id: \cf6 \strokec6 'add-image'\cf0 \strokec4 ,\cb1 \
\cb3         icon: \cf5 \strokec5 Users\cf0 \strokec4 ,\cb1 \
\cb3         label: \cf6 \strokec6 'Add team/people image'\cf0 \strokec4 ,\cb1 \
\cb3         description: \cf6 \strokec6 'Generate relevant imagery'\cf0 \strokec4 ,\cb1 \
\cb3         type: \cf6 \strokec6 'image'\cf0 \strokec4 ,\cb1 \
\cb3         color: \cf6 \strokec6 'text-green-600 bg-green-50'\cf0 \cb1 \strokec4 \
\cb3       \});\cb1 \
\cb3     \}\cb1 \
\
\cb3     \cf7 \strokec7 // Always available smart suggestions\cf0 \cb1 \strokec4 \
\cb3     \cf2 \strokec2 const\cf0 \strokec4  defaultSuggestions = [\cb1 \
\cb3       \{\cb1 \
\cb3         id: \cf6 \strokec6 'enhance-content'\cf0 \strokec4 ,\cb1 \
\cb3         icon: \cf5 \strokec5 Sparkles\cf0 \strokec4 ,\cb1 \
\cb3         label: \cf6 \strokec6 'Enhance this slide'\cf0 \strokec4 ,\cb1 \
\cb3         description: \cf6 \strokec6 'Make content more impactful'\cf0 \strokec4 ,\cb1 \
\cb3         type: \cf6 \strokec6 'enhance'\cf0 \strokec4 ,\cb1 \
\cb3         color: \cf6 \strokec6 'text-purple-600 bg-purple-50'\cf0 \cb1 \strokec4 \
\cb3       \},\cb1 \
\cb3       \{\cb1 \
\cb3         id: \cf6 \strokec6 'add-visual'\cf0 \strokec4 ,\cb1 \
\cb3         icon: \cf5 \strokec5 Image\cf0 \strokec4 ,\cb1 \
\cb3         label: \cf6 \strokec6 'Suggest visuals'\cf0 \strokec4 ,\cb1 \
\cb3         description: \cf6 \strokec6 'AI will find perfect images'\cf0 \strokec4 ,\cb1 \
\cb3         type: \cf6 \strokec6 'image'\cf0 \strokec4 ,\cb1 \
\cb3         color: \cf6 \strokec6 'text-pink-600 bg-pink-50'\cf0 \cb1 \strokec4 \
\cb3       \},\cb1 \
\cb3       \{\cb1 \
\cb3         id: \cf6 \strokec6 'add-quote'\cf0 \strokec4 ,\cb1 \
\cb3         icon: \cf5 \strokec5 Quote\cf0 \strokec4 ,\cb1 \
\cb3         label: \cf6 \strokec6 'Add relevant quote'\cf0 \strokec4 ,\cb1 \
\cb3         description: \cf6 \strokec6 'Find an inspiring quote'\cf0 \strokec4 ,\cb1 \
\cb3         type: \cf6 \strokec6 'quote'\cf0 \strokec4 ,\cb1 \
\cb3         color: \cf6 \strokec6 'text-indigo-600 bg-indigo-50'\cf0 \cb1 \strokec4 \
\cb3       \}\cb1 \
\cb3     ];\cb1 \
\
\cb3     setSuggestions([...baseSuggestions, ...defaultSuggestions].slice(\cf8 \strokec8 0\cf0 \strokec4 , \cf8 \strokec8 4\cf0 \strokec4 ));\cb1 \
\cb3     setIsGenerating(\cf2 \strokec2 false\cf0 \strokec4 );\cb1 \
\cb3   \};\cb1 \
\
\cb3   \cf2 \strokec2 const\cf0 \strokec4  applySuggestion = \cf2 \strokec2 async\cf0 \strokec4  (suggestion) => \{\cb1 \
\cb3     setAppliedSuggestions(prev => \cf2 \strokec2 new\cf0 \strokec4  \cf5 \strokec5 Set\cf0 \strokec4 ([...prev, suggestion.id]));\cb1 \
\cb3     \cb1 \
\cb3     \cf2 \strokec2 try\cf0 \strokec4  \{\cb1 \
\cb3       \cf2 \strokec2 switch\cf0 \strokec4  (suggestion.type) \{\cb1 \
\cb3         \cf2 \strokec2 case\cf0 \strokec4  \cf6 \strokec6 'enhance'\cf0 \strokec4 :\cb1 \
\cb3           \cf2 \strokec2 const\cf0 \strokec4  enhanced = \cf2 \strokec2 await\cf0 \strokec4  base44.integrations.\cf5 \strokec5 Core\cf0 \strokec4 .\cf5 \strokec5 InvokeLLM\cf0 \strokec4 (\{\cb1 \
\cb3             prompt: \cf6 \strokec6 `Enhance this slide to be more impactful and professional. Title: \cf0 \strokec4 $\{slide.title\}\cf6 \strokec6 . Content: \cf0 \strokec4 $\{slide.content?.join(\cf6 \strokec6 ', '\cf0 \strokec4 )\}\cf6 \strokec6 . Make it concise but powerful.`\cf0 \strokec4 ,\cb1 \
\cb3             response_json_schema: \{\cb1 \
\cb3               type: \cf6 \strokec6 "object"\cf0 \strokec4 ,\cb1 \
\cb3               properties: \{\cb1 \
\cb3                 title: \{ type: \cf6 \strokec6 "string"\cf0 \strokec4  \},\cb1 \
\cb3                 content: \{ type: \cf6 \strokec6 "array"\cf0 \strokec4 , items: \{ type: \cf6 \strokec6 "string"\cf0 \strokec4  \} \}\cb1 \
\cb3               \}\cb1 \
\cb3             \}\cb1 \
\cb3           \});\cb1 \
\cb3           onUpdateSlide(\{ ...slide, title: enhanced.title, content: enhanced.content \});\cb1 \
\cb3           toast.success(\cf6 \strokec6 'Slide enhanced!'\cf0 \strokec4 );\cb1 \
\cb3           \cf2 \strokec2 break\cf0 \strokec4 ;\cb1 \
\
\cb3         \cf2 \strokec2 case\cf0 \strokec4  \cf6 \strokec6 'quote'\cf0 \strokec4 :\cb1 \
\cb3           \cf2 \strokec2 const\cf0 \strokec4  quoteResult = \cf2 \strokec2 await\cf0 \strokec4  base44.integrations.\cf5 \strokec5 Core\cf0 \strokec4 .\cf5 \strokec5 InvokeLLM\cf0 \strokec4 (\{\cb1 \
\cb3             prompt: \cf6 \strokec6 `Find a relevant, inspiring quote that relates to this topic: \cf0 \strokec4 $\{slide.title\}\cf6 \strokec6 . Return a famous quote with attribution.`\cf0 \strokec4 ,\cb1 \
\cb3             response_json_schema: \{\cb1 \
\cb3               type: \cf6 \strokec6 "object"\cf0 \strokec4 ,\cb1 \
\cb3               properties: \{\cb1 \
\cb3                 quote: \{ type: \cf6 \strokec6 "string"\cf0 \strokec4  \},\cb1 \
\cb3                 author: \{ type: \cf6 \strokec6 "string"\cf0 \strokec4  \}\cb1 \
\cb3               \}\cb1 \
\cb3             \}\cb1 \
\cb3           \});\cb1 \
\cb3           \cf2 \strokec2 const\cf0 \strokec4  newContent = [...(slide.content || []), \cf6 \strokec6 `"\cf0 \strokec4 $\{quoteResult.quote\}\cf6 \strokec6 " \'97 \cf0 \strokec4 $\{quoteResult.author\}\cf6 \strokec6 `\cf0 \strokec4 ];\cb1 \
\cb3           onUpdateSlide(\{ ...slide, content: newContent \});\cb1 \
\cb3           toast.success(\cf6 \strokec6 'Quote added!'\cf0 \strokec4 );\cb1 \
\cb3           \cf2 \strokec2 break\cf0 \strokec4 ;\cb1 \
\
\cb3         \cf2 \strokec2 case\cf0 \strokec4  \cf6 \strokec6 'image'\cf0 \strokec4 :\cb1 \
\cb3           \cf2 \strokec2 const\cf0 \strokec4  imagePrompt = \cf6 \strokec6 `Professional, modern image for a presentation about: \cf0 \strokec4 $\{slide.title\}\cf6 \strokec6 . High quality, business appropriate.`\cf0 \strokec4 ;\cb1 \
\cb3           \cf2 \strokec2 const\cf0 \strokec4  imageResult = \cf2 \strokec2 await\cf0 \strokec4  base44.integrations.\cf5 \strokec5 Core\cf0 \strokec4 .\cf5 \strokec5 GenerateImage\cf0 \strokec4 (\{ prompt: imagePrompt \});\cb1 \
\cb3           \cf2 \strokec2 if\cf0 \strokec4  (imageResult?.url && onAddImage) \{\cb1 \
\cb3             onAddImage(imageResult.url);\cb1 \
\cb3             toast.success(\cf6 \strokec6 'Image generated!'\cf0 \strokec4 );\cb1 \
\cb3           \}\cb1 \
\cb3           \cf2 \strokec2 break\cf0 \strokec4 ;\cb1 \
\
\cb3         \cf2 \strokec2 case\cf0 \strokec4  \cf6 \strokec6 'chart'\cf0 \strokec4 :\cb1 \
\cb3           \cf2 \strokec2 if\cf0 \strokec4  (onAddChart) \{\cb1 \
\cb3             onAddChart(\{\cb1 \
\cb3               type: \cf6 \strokec6 'bar'\cf0 \strokec4 ,\cb1 \
\cb3               data: [\cb1 \
\cb3                 \{ name: \cf6 \strokec6 'Q1'\cf0 \strokec4 , value: \cf8 \strokec8 30\cf0 \strokec4  \},\cb1 \
\cb3                 \{ name: \cf6 \strokec6 'Q2'\cf0 \strokec4 , value: \cf8 \strokec8 45\cf0 \strokec4  \},\cb1 \
\cb3                 \{ name: \cf6 \strokec6 'Q3'\cf0 \strokec4 , value: \cf8 \strokec8 60\cf0 \strokec4  \},\cb1 \
\cb3                 \{ name: \cf6 \strokec6 'Q4'\cf0 \strokec4 , value: \cf8 \strokec8 80\cf0 \strokec4  \}\cb1 \
\cb3               ]\cb1 \
\cb3             \});\cb1 \
\cb3             toast.success(\cf6 \strokec6 'Chart added! Edit the data in the chart panel.'\cf0 \strokec4 );\cb1 \
\cb3           \}\cb1 \
\cb3           \cf2 \strokec2 break\cf0 \strokec4 ;\cb1 \
\
\cb3         \cf2 \strokec2 default\cf0 \strokec4 :\cb1 \
\cb3           toast.info(\cf6 \strokec6 'Coming soon!'\cf0 \strokec4 );\cb1 \
\cb3       \}\cb1 \
\cb3     \} \cf2 \strokec2 catch\cf0 \strokec4  (error) \{\cb1 \
\cb3       toast.error(\cf6 \strokec6 'Failed to apply suggestion'\cf0 \strokec4 );\cb1 \
\cb3     \}\cb1 \
\cb3     \cb1 \
\cb3     setTimeout(() => \{\cb1 \
\cb3       setAppliedSuggestions(prev => \{\cb1 \
\cb3         \cf2 \strokec2 const\cf0 \strokec4  next = \cf2 \strokec2 new\cf0 \strokec4  \cf5 \strokec5 Set\cf0 \strokec4 (prev);\cb1 \
\cb3         next.\cf2 \strokec2 delete\cf0 \strokec4 (suggestion.id);\cb1 \
\cb3         \cf2 \strokec2 return\cf0 \strokec4  next;\cb1 \
\cb3       \});\cb1 \
\cb3     \}, \cf8 \strokec8 2000\cf0 \strokec4 );\cb1 \
\cb3   \};\cb1 \
\
\cb3   \cf2 \strokec2 if\cf0 \strokec4  (!isVisible || suggestions.length === \cf8 \strokec8 0\cf0 \strokec4 ) \cf2 \strokec2 return\cf0 \strokec4  \cf2 \strokec2 null\cf0 \strokec4 ;\cb1 \
\
\cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <motion.div\cb1 \
\cb3       initial=\{\{ opacity: \cf8 \strokec8 0\cf0 \strokec4 , y: -\cf8 \strokec8 10\cf0 \strokec4  \}\}\cb1 \
\cb3       animate=\{\{ opacity: \cf8 \strokec8 1\cf0 \strokec4 , y: \cf8 \strokec8 0\cf0 \strokec4  \}\}\cb1 \
\cb3       className=\cf6 \strokec6 "absolute top-4 right-4 z-20"\cf0 \cb1 \strokec4 \
\cb3     >\cb1 \
\cb3       <div className=\cf6 \strokec6 "bg-white/95 backdrop-blur-sm rounded-xl shadow-lg border border-slate-200 p-3 w-64"\cf0 \strokec4 >\cb1 \
\cb3         <div className=\cf6 \strokec6 "flex items-center justify-between mb-3"\cf0 \strokec4 >\cb1 \
\cb3           <div className=\cf6 \strokec6 "flex items-center gap-2"\cf0 \strokec4 >\cb1 \
\cb3             <div className=\cf6 \strokec6 "w-6 h-6 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center"\cf0 \strokec4 >\cb1 \
\cb3               <\cf5 \strokec5 Zap\cf0 \strokec4  className=\cf6 \strokec6 "w-3 h-3 text-white"\cf0 \strokec4  />\cb1 \
\cb3             </div>\cb1 \
\cb3             <span className=\cf6 \strokec6 "text-xs font-semibold text-slate-700"\cf0 \strokec4 >\cf5 \strokec5 AI\cf0 \strokec4  \cf5 \strokec5 Suggestions\cf0 \strokec4 </span>\cb1 \
\cb3           </div>\cb1 \
\cb3           <button \cb1 \
\cb3             onClick=\{() => setIsVisible(\cf2 \strokec2 false\cf0 \strokec4 )\}\cb1 \
\cb3             className=\cf6 \strokec6 "text-slate-400 hover:text-slate-600"\cf0 \cb1 \strokec4 \
\cb3           >\cb1 \
\cb3             <\cf5 \strokec5 X\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3           </button>\cb1 \
\cb3         </div>\cb1 \
\
\cb3         <div className=\cf6 \strokec6 "space-y-2"\cf0 \strokec4 >\cb1 \
\cb3           <\cf5 \strokec5 AnimatePresence\cf0 \strokec4 >\cb1 \
\cb3             \{suggestions.map((suggestion, idx) => \{\cb1 \
\cb3               \cf2 \strokec2 const\cf0 \strokec4  \cf5 \strokec5 Icon\cf0 \strokec4  = suggestion.icon;\cb1 \
\cb3               \cf2 \strokec2 const\cf0 \strokec4  isApplying = appliedSuggestions.has(suggestion.id);\cb1 \
\cb3               \cb1 \
\cb3               \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3                 <motion.button\cb1 \
\cb3                   key=\{suggestion.id\}\cb1 \
\cb3                   initial=\{\{ opacity: \cf8 \strokec8 0\cf0 \strokec4 , x: -\cf8 \strokec8 10\cf0 \strokec4  \}\}\cb1 \
\cb3                   animate=\{\{ opacity: \cf8 \strokec8 1\cf0 \strokec4 , x: \cf8 \strokec8 0\cf0 \strokec4  \}\}\cb1 \
\cb3                   transition=\{\{ delay: idx * \cf8 \strokec8 0.1\cf0 \strokec4  \}\}\cb1 \
\cb3                   onClick=\{() => applySuggestion(suggestion)\}\cb1 \
\cb3                   disabled=\{isApplying\}\cb1 \
\cb3                   className=\{\cf6 \strokec6 `w-full p-2 rounded-lg text-left transition-all flex items-start gap-2 group \cf0 \strokec4 $\{\cb1 \
\cb3                     isApplying \cb1 \
\cb3                       ? \cf6 \strokec6 'bg-green-50 border border-green-200'\cf0 \strokec4  \cb1 \
\cb3                       : \cf6 \strokec6 'hover:bg-slate-50 border border-transparent hover:border-slate-200'\cf0 \cb1 \strokec4 \
\cb3                   \}\cf6 \strokec6 `\cf0 \strokec4 \}\cb1 \
\cb3                 >\cb1 \
\cb3                   <div className=\{\cf6 \strokec6 `w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 \cf0 \strokec4 $\{suggestion.color\}\cf6 \strokec6 `\cf0 \strokec4 \}>\cb1 \
\cb3                     \{isApplying ? (\cb1 \
\cb3                       <div className=\cf6 \strokec6 "w-4 h-4 border-2 border-green-600 border-t-transparent rounded-full animate-spin"\cf0 \strokec4  />\cb1 \
\cb3                     ) : (\cb1 \
\cb3                       <\cf5 \strokec5 Icon\cf0 \strokec4  className=\cf6 \strokec6 "w-4 h-4"\cf0 \strokec4  />\cb1 \
\cb3                     )\}\cb1 \
\cb3                   </div>\cb1 \
\cb3                   <div className=\cf6 \strokec6 "flex-1 min-w-0"\cf0 \strokec4 >\cb1 \
\cb3                     <p className=\cf6 \strokec6 "text-xs font-medium text-slate-700 truncate"\cf0 \strokec4 >\cb1 \
\cb3                       \{suggestion.label\}\cb1 \
\cb3                     </p>\cb1 \
\cb3                     <p className=\cf6 \strokec6 "text-[10px] text-slate-400 truncate"\cf0 \strokec4 >\cb1 \
\cb3                       \{suggestion.description\}\cb1 \
\cb3                     </p>\cb1 \
\cb3                   </div>\cb1 \
\cb3                   <\cf5 \strokec5 ArrowRight\cf0 \strokec4  className=\cf6 \strokec6 "w-3 h-3 text-slate-300 group-hover:text-slate-500 flex-shrink-0 mt-1 opacity-0 group-hover:opacity-100 transition-opacity"\cf0 \strokec4  />\cb1 \
\cb3                 </motion.button>\cb1 \
\cb3               );\cb1 \
\cb3             \})\}\cb1 \
\cb3           </\cf5 \strokec5 AnimatePresence\cf0 \strokec4 >\cb1 \
\cb3         </div>\cb1 \
\
\cb3         <button\cb1 \
\cb3           onClick=\{generateSuggestions\}\cb1 \
\cb3           className=\cf6 \strokec6 "mt-2 w-full text-center text-[10px] text-indigo-600 hover:text-indigo-700 font-medium"\cf0 \cb1 \strokec4 \
\cb3         >\cb1 \
\cb3           \cf9 \strokec9 \uc0\u8635 \cf0 \strokec4  \cf5 \strokec5 Refresh\cf0 \strokec4  suggestions\cb1 \
\cb3         </button>\cb1 \
\cb3       </div>\cb1 \
\cb3     </motion.div>\cb1 \
\cb3   );\cb1 \
\cb3 \}\cb1 \
}