{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red14\green110\blue109;\red144\green1\blue18;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c0\c50196\c50196;\cssrgb\c63922\c8235\c8235;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 import\cf0 \strokec4  \cf5 \strokec5 React\cf0 \strokec4  \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 'react'\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Card\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/card"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ \cf5 \strokec5 Label\cf0 \strokec4  \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/components/ui/label"\cf0 \strokec4 ;\cb1 \
\cf2 \cb3 \strokec2 import\cf0 \strokec4  \{ cn \} \cf2 \strokec2 from\cf0 \strokec4  \cf6 \strokec6 "@/lib/utils"\cf0 \strokec4 ;\cb1 \
\
\cf2 \cb3 \strokec2 const\cf0 \strokec4  colorThemes = [\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \{ \cb1 \
\cb3     name: \cf6 \strokec6 'Indigo Dream'\cf0 \strokec4 , \cb1 \
\cb3     primary: \cf6 \strokec6 '#4f46e5'\cf0 \strokec4 , \cb1 \
\cb3     secondary: \cf6 \strokec6 '#8b5cf6'\cf0 \strokec4 ,\cb1 \
\cb3     accent: \cf6 \strokec6 '#ec4899'\cf0 \strokec4 ,\cb1 \
\cb3     background: \cf6 \strokec6 '#ffffff'\cf0 \cb1 \strokec4 \
\cb3   \},\cb1 \
\cb3   \{ \cb1 \
\cb3     name: \cf6 \strokec6 'Ocean Blue'\cf0 \strokec4 , \cb1 \
\cb3     primary: \cf6 \strokec6 '#0284c7'\cf0 \strokec4 , \cb1 \
\cb3     secondary: \cf6 \strokec6 '#06b6d4'\cf0 \strokec4 ,\cb1 \
\cb3     accent: \cf6 \strokec6 '#22d3ee'\cf0 \strokec4 ,\cb1 \
\cb3     background: \cf6 \strokec6 '#f0f9ff'\cf0 \cb1 \strokec4 \
\cb3   \},\cb1 \
\cb3   \{ \cb1 \
\cb3     name: \cf6 \strokec6 'Forest Green'\cf0 \strokec4 , \cb1 \
\cb3     primary: \cf6 \strokec6 '#059669'\cf0 \strokec4 , \cb1 \
\cb3     secondary: \cf6 \strokec6 '#10b981'\cf0 \strokec4 ,\cb1 \
\cb3     accent: \cf6 \strokec6 '#34d399'\cf0 \strokec4 ,\cb1 \
\cb3     background: \cf6 \strokec6 '#f0fdf4'\cf0 \cb1 \strokec4 \
\cb3   \},\cb1 \
\cb3   \{ \cb1 \
\cb3     name: \cf6 \strokec6 'Sunset Orange'\cf0 \strokec4 , \cb1 \
\cb3     primary: \cf6 \strokec6 '#ea580c'\cf0 \strokec4 , \cb1 \
\cb3     secondary: \cf6 \strokec6 '#f97316'\cf0 \strokec4 ,\cb1 \
\cb3     accent: \cf6 \strokec6 '#fb923c'\cf0 \strokec4 ,\cb1 \
\cb3     background: \cf6 \strokec6 '#fff7ed'\cf0 \cb1 \strokec4 \
\cb3   \},\cb1 \
\cb3   \{ \cb1 \
\cb3     name: \cf6 \strokec6 'Royal Purple'\cf0 \strokec4 , \cb1 \
\cb3     primary: \cf6 \strokec6 '#7c3aed'\cf0 \strokec4 , \cb1 \
\cb3     secondary: \cf6 \strokec6 '#a78bfa'\cf0 \strokec4 ,\cb1 \
\cb3     accent: \cf6 \strokec6 '#c4b5fd'\cf0 \strokec4 ,\cb1 \
\cb3     background: \cf6 \strokec6 '#faf5ff'\cf0 \cb1 \strokec4 \
\cb3   \},\cb1 \
\cb3   \{ \cb1 \
\cb3     name: \cf6 \strokec6 'Monochrome'\cf0 \strokec4 , \cb1 \
\cb3     primary: \cf6 \strokec6 '#1e293b'\cf0 \strokec4 , \cb1 \
\cb3     secondary: \cf6 \strokec6 '#475569'\cf0 \strokec4 ,\cb1 \
\cb3     accent: \cf6 \strokec6 '#94a3b8'\cf0 \strokec4 ,\cb1 \
\cb3     background: \cf6 \strokec6 '#f8fafc'\cf0 \cb1 \strokec4 \
\cb3   \},\cb1 \
\cb3 ];\cb1 \
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 default\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  \cf5 \strokec5 ColorThemePanel\cf0 \strokec4 (\{ currentTheme, onThemeChange \}) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3   \cf2 \strokec2 return\cf0 \strokec4  (\cb1 \
\cb3     <\cf5 \strokec5 Card\cf0 \strokec4  className=\cf6 \strokec6 "p-4"\cf0 \strokec4 >\cb1 \
\cb3       <\cf5 \strokec5 Label\cf0 \strokec4  className=\cf6 \strokec6 "text-sm font-semibold mb-3 block"\cf0 \strokec4 >\cf5 \strokec5 Color\cf0 \strokec4  \cf5 \strokec5 Theme\cf0 \strokec4 </\cf5 \strokec5 Label\cf0 \strokec4 >\cb1 \
\cb3       <div className=\cf6 \strokec6 "space-y-2"\cf0 \strokec4 >\cb1 \
\cb3         \{colorThemes.map((theme) => (\cb1 \
\cb3           <button\cb1 \
\cb3             key=\{theme.name\}\cb1 \
\cb3             onClick=\{() => onThemeChange(theme)\}\cb1 \
\cb3             className=\{cn(\cb1 \
\cb3               \cf6 \strokec6 "w-full p-3 rounded-lg border-2 transition-all text-left"\cf0 \strokec4 ,\cb1 \
\cb3               currentTheme?.name === theme.name\cb1 \
\cb3                 ? \cf6 \strokec6 "border-indigo-600 bg-indigo-50"\cf0 \cb1 \strokec4 \
\cb3                 : \cf6 \strokec6 "border-slate-200 hover:border-slate-300"\cf0 \cb1 \strokec4 \
\cb3             )\}\cb1 \
\cb3           >\cb1 \
\cb3             <div className=\cf6 \strokec6 "flex items-center justify-between mb-2"\cf0 \strokec4 >\cb1 \
\cb3               <span className=\cf6 \strokec6 "font-medium text-sm"\cf0 \strokec4 >\{theme.name\}</span>\cb1 \
\cb3             </div>\cb1 \
\cb3             <div className=\cf6 \strokec6 "flex gap-1"\cf0 \strokec4 >\cb1 \
\cb3               <div \cb1 \
\cb3                 className=\cf6 \strokec6 "w-8 h-8 rounded"\cf0 \strokec4  \cb1 \
\cb3                 style=\{\{ backgroundColor: theme.primary \}\}\cb1 \
\cb3               />\cb1 \
\cb3               <div \cb1 \
\cb3                 className=\cf6 \strokec6 "w-8 h-8 rounded"\cf0 \strokec4  \cb1 \
\cb3                 style=\{\{ backgroundColor: theme.secondary \}\}\cb1 \
\cb3               />\cb1 \
\cb3               <div \cb1 \
\cb3                 className=\cf6 \strokec6 "w-8 h-8 rounded"\cf0 \strokec4  \cb1 \
\cb3                 style=\{\{ backgroundColor: theme.accent \}\}\cb1 \
\cb3               />\cb1 \
\cb3               <div \cb1 \
\cb3                 className=\cf6 \strokec6 "w-8 h-8 rounded border border-slate-200"\cf0 \strokec4  \cb1 \
\cb3                 style=\{\{ backgroundColor: theme.background \}\}\cb1 \
\cb3               />\cb1 \
\cb3             </div>\cb1 \
\cb3           </button>\cb1 \
\cb3         ))\}\cb1 \
\cb3       </div>\cb1 \
\cb3     </\cf5 \strokec5 Card\cf0 \strokec4 >\cb1 \
\cb3   );\cb1 \
\cb3 \}\cb1 \
}